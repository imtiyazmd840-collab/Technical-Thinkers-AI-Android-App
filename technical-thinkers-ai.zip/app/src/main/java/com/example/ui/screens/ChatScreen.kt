package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import android.content.Intent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.os.Bundle
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChatMessage
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.glassCard
import com.example.ui.theme.glassChip
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.components.InteractiveVisualizer
import com.example.ui.components.TeachMeLessonView
import com.example.ui.components.LiveVoiceOverlay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onOpenDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val clipboardManager = LocalClipboardManager.current

    val messages by viewModel.currentMessages.collectAsState()
    val isReplying by viewModel.isReplying.collectAsState()
    val inputText by viewModel.inputMessage.collectAsState()
    val sessions by viewModel.allSessions.collectAsState()
    val currentSessionId by viewModel.currentSessionId.collectAsState()
    val userGender by viewModel.userPrefs.userGender.collectAsState()

    var showMenu by remember { mutableStateOf(false) }
    var showSessionsDropdown by remember { mutableStateOf(false) }

    // Visual, Lesson, Voice state overlays
    var showVisualOverlay by remember { mutableStateOf(false) }
    var showLessonOverlay by remember { mutableStateOf(false) }
    var showVoiceOverlay by remember { mutableStateOf(false) }

    val activeVisual by viewModel.activeVisual.collectAsState()
    val isGeneratingVisual by viewModel.isGeneratingVisual.collectAsState()
    val activeLesson by viewModel.activeLesson.collectAsState()
    val isGeneratingLesson by viewModel.isGeneratingLesson.collectAsState()

    // Speech-to-Text States
    var isListening by remember { mutableStateOf(false) }
    var speechError by remember { mutableStateOf<String?>(null) }
    val isSpeechAvailable = remember { SpeechRecognizer.isRecognitionAvailable(context) }

    val speechRecognizer = remember {
        try {
            SpeechRecognizer.createSpeechRecognizer(context)
        } catch (e: Exception) {
            null
        }
    }

    val speechRecognizerIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "te-IN")
            putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayListOf("te-IN", "en-IN"))
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "te-IN")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
    }

    val listener = remember {
        object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListening = true
                speechError = null
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isListening = false
            }
            override fun onError(error: Int) {
                isListening = false
                val msg = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                    SpeechRecognizer.ERROR_CLIENT -> "Client side error"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic permission required! 🎙️"
                    SpeechRecognizer.ERROR_NETWORK -> "Network error"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                    SpeechRecognizer.ERROR_NO_MATCH -> "No match found. Clear ga cheppu Maawa/Madammm! 🗣️"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer is busy"
                    SpeechRecognizer.ERROR_SERVER -> "Server error"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input. Edaina cheppu Maawa/Madammm! 🗣️"
                    else -> "Speech recognition error"
                }
                speechError = msg
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val text = matches[0]
                    viewModel.onInputChange(text)
                }
                isListening = false
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val text = matches[0]
                    viewModel.onInputChange(text)
                }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    DisposableEffect(speechRecognizer) {
        speechRecognizer?.setRecognitionListener(listener)
        onDispose {
            speechRecognizer?.destroy()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            if (isGranted) {
                try {
                    speechRecognizer?.startListening(speechRecognizerIntent)
                    isListening = true
                } catch (e: Exception) {
                    speechError = "Could not start listening: ${e.message}"
                }
            } else {
                speechError = "Mic permission is required to speak, Maawa/Madammm! 🎙️"
            }
        }
    )

    val toggleListening = {
        if (isListening) {
            speechRecognizer?.stopListening()
            isListening = false
        } else {
            speechError = null
            val permissionCheck = androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            )
            if (permissionCheck == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                try {
                    speechRecognizer?.startListening(speechRecognizerIntent)
                    isListening = true
                } catch (e: Exception) {
                    speechError = "Could not start listening: ${e.message}"
                }
            } else {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val micScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_scale"
    )

    // Auto-scroll to the bottom when messages change
    LaunchedEffect(messages.size, isReplying) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val genderTitle = viewModel.userPrefs.getGenderTitle()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Open Drawer",
                            tint = BrandPrimary
                        )
                    }
                },
                title = {
                    Box {
                        TextButton(
                            onClick = { showSessionsDropdown = true },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.onBackground)
                        ) {
                            val activeTitle = sessions.find { it.id == currentSessionId }?.title ?: "Select Session"
                            Text(
                                text = activeTitle,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                maxLines = 1
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Switch Sessions"
                            )
                        }

                        DropdownMenu(
                            expanded = showSessionsDropdown,
                            onDismissRequest = { showSessionsDropdown = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("+ Start New Chat", fontWeight = FontWeight.Bold, color = BrandPrimary) },
                                onClick = {
                                    viewModel.startNewChat()
                                    showSessionsDropdown = false
                                }
                            )
                            HorizontalDivider()
                            if (sessions.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("No active sessions") },
                                    onClick = {},
                                    enabled = false
                                )
                            } else {
                                sessions.forEach { session ->
                                    DropdownMenuItem(
                                        text = { Text(session.title) },
                                        onClick = {
                                            viewModel.selectSession(session.id)
                                            showSessionsDropdown = false
                                        },
                                        trailingIcon = {
                                            IconButton(
                                                onClick = { viewModel.deleteSession(session.id) }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Delete Thread",
                                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { showVoiceOverlay = true }) {
                        Icon(imageVector = Icons.Default.Call, contentDescription = "Live Voice Call", tint = BrandPrimary)
                    }
                    IconButton(onClick = { viewModel.startNewChat() }) {
                        Icon(imageVector = Icons.Default.AddComment, contentDescription = "New Chat", tint = BrandPrimary)
                    }
                    IconButton(onClick = { showMenu = true }) {
                        Icon(imageVector = Icons.Default.MoreVert, contentDescription = "Menu")
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Clear Chat") },
                            onClick = {
                                viewModel.clearCurrentSession()
                                showMenu = false
                            },
                            leadingIcon = { Icon(Icons.Default.ClearAll, contentDescription = "Clear") }
                        )
                        DropdownMenuItem(
                            text = { Text("Export Chat") },
                            onClick = {
                                val log = viewModel.exportChatHistory()
                                clipboardManager.setText(AnnotatedString(log))
                                Toast.makeText(context, "Chat details copied to clipboard Maawaaa! 📋", Toast.LENGTH_LONG).show()
                                showMenu = false
                            },
                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = "Export") }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete This Thread") },
                            onClick = {
                                currentSessionId?.let { viewModel.deleteSession(it) }
                                showMenu = false
                            },
                            leadingIcon = { Icon(Icons.Default.DeleteForever, contentDescription = "Delete") }
                        )
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Message List
            if (messages.isEmpty() && !isReplying) {
                // Empty Chat Greeting Page
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(BrandPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = "Robot",
                            tint = BrandPrimary,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Text(
                        text = "Hi $genderTitle! 👋",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Welcome to Technical Thinkers!",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Cheppu ivvala em nerchukundam anukuntunav? 😄\nNenu fully ready answers cheppadaniki!",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                        lineHeight = 20.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    // Quick suggested questions (Glassmorphic)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .glassCard(elevation = 2.dp)
                            .padding(16.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = "Try these starters:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = BrandPrimary
                            )
                            listOf(
                                "Suggest tech career tips for beginners 📈",
                                "Write a beautiful Kotlin Compose Button code 📱",
                                "Explain artificial intelligence in easy Tenglish 🤖"
                            ).forEach { prompt ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .glassChip(cornerRadius = 10.dp)
                                        .clickable { viewModel.sendSuggestionPrompt(prompt) }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ChatBubbleOutline,
                                        contentDescription = "Ask",
                                        tint = BrandPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = prompt,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)
                ) {
                    items(messages) { message ->
                        ChatBubble(
                            message = message,
                            onVisualize = {
                                val words = message.content.trim().split("\\s+".toRegex())
                                val topic = if (words.size > 3) words.take(3).joinToString(" ") else message.content
                                viewModel.generateVisualization(topic, message.content)
                                showVisualOverlay = true
                            },
                            onTeachMe = {
                                val words = message.content.trim().split("\\s+".toRegex())
                                val topic = if (words.size > 3) words.take(3).joinToString(" ") else message.content
                                viewModel.generateTeachMeLesson(topic)
                                showLessonOverlay = true
                            }
                        )
                    }

                    if (isReplying) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(BrandPrimary.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SmartToy,
                                        contentDescription = "AI",
                                        tint = BrandPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Box(
                                    modifier = Modifier
                                        .glassCard(cornerRadius = 16.dp, elevation = 1.dp)
                                        .padding(horizontal = 16.dp, vertical = 12.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            strokeWidth = 2.dp,
                                            color = BrandPrimary
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = "TT AI alochisthundi Maawaaa... ⚡",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // STT / Speech Recognition Banner
            AnimatedVisibility(visible = isListening || speechError != null) {
                Surface(
                    color = if (speechError != null) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f)
                            else BrandPrimary.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        if (isListening) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = BrandPrimary
                            )
                            Text(
                                text = "Listening... Speak in Tenglish/Telugu/English! 🎙️",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        } else if (speechError != null) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = "Error",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = speechError ?: "",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { speechError = null },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Dismiss",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Input Row
            Surface(
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.background
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.ime)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TextField(
                        value = inputText,
                        onValueChange = { viewModel.onInputChange(it) },
                        placeholder = { Text("Malli em nerchukundam $genderTitle? 😄") },
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(24.dp))
                            .testTag("chat_input"),
                        leadingIcon = {
                            IconButton(
                                onClick = { toggleListening() },
                                modifier = Modifier
                                    .size(36.dp)
                                    .scale(if (isListening) micScale else 1f)
                                    .testTag("mic_button")
                            ) {
                                Icon(
                                    imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                                    contentDescription = "Speak in Tenglish",
                                    tint = if (isListening) Color.Red else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        keyboardOptions = KeyboardOptions(
                            imeAction = ImeAction.Send,
                            capitalization = KeyboardCapitalization.Sentences
                        ),
                        keyboardActions = KeyboardActions(
                            onSend = { viewModel.sendMessage() }
                        ),
                        maxLines = 4
                    )

                    IconButton(
                        onClick = { viewModel.sendMessage() },
                        enabled = inputText.trim().isNotEmpty() && !isReplying,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (inputText.trim().isNotEmpty() && !isReplying) BrandPrimary else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .testTag("send_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = if (inputText.trim().isNotEmpty() && !isReplying) Color.White else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------
    // OVERLAY: VISUALIZATION SCREEN
    // -------------------------------------------------------------
    if (showVisualOverlay) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
        ) {
            if (isGeneratingVisual) {
                Card(
                    modifier = Modifier
                        .size(240.dp, 160.dp)
                        .align(Alignment.Center),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = BrandPrimary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Drawing diagram... 🎨",
                            fontWeight = FontWeight.Bold,
                            color = BrandPrimary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Designing components...",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }
                }
            } else {
                activeVisual?.let { visual ->
                    InteractiveVisualizer(
                        visual = visual,
                        onClose = {
                            viewModel.clearActiveVisual()
                            showVisualOverlay = false
                        }
                    )
                } ?: run {
                    LaunchedEffect(Unit) {
                        showVisualOverlay = false
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------
    // OVERLAY: TEACH ME LESSON SCREEN
    // -------------------------------------------------------------
    if (showLessonOverlay) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
        ) {
            if (isGeneratingLesson) {
                Card(
                    modifier = Modifier
                        .size(240.dp, 160.dp)
                        .align(Alignment.Center),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = BrandPrimary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Building Lesson... 🎓",
                            fontWeight = FontWeight.Bold,
                            color = BrandPrimary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Adapting level...",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }
                }
            } else {
                activeLesson?.let { lesson ->
                    TeachMeLessonView(
                        lesson = lesson,
                        onClose = {
                            viewModel.clearActiveLesson()
                            showLessonOverlay = false
                        }
                    )
                } ?: run {
                    LaunchedEffect(Unit) {
                        showLessonOverlay = false
                    }
                }
            }
        }
    }

    // -------------------------------------------------------------
    // OVERLAY: LIVE VOICE MODE OVERLAY
    // -------------------------------------------------------------
    if (showVoiceOverlay) {
        LiveVoiceOverlay(
            viewModel = viewModel,
            onClose = { showVoiceOverlay = false }
        )
    }
}

@Composable
fun ChatBubble(
    message: ChatMessage,
    onVisualize: () -> Unit,
    onTeachMe: () -> Unit
) {
    val isUser = message.role == "user"
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .padding(top = 4.dp)
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(BrandPrimary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.SmartToy,
                    contentDescription = "AI",
                    tint = BrandPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
        }

        if (isUser) {
            Card(
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 0.dp, bottomStart = 16.dp, bottomEnd = 16.dp),
                colors = CardDefaults.cardColors(containerColor = BrandPrimary),
                modifier = Modifier
                    .weight(1f, fill = false)
                    .widthIn(max = 280.dp)
                    .testTag("user_bubble")
            ) {
                Column(
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = message.content,
                        color = Color.White,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .widthIn(max = 280.dp)
                    .testTag("ai_bubble")
                    .glassCard(cornerRadius = 16.dp, elevation = 1.dp)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Column {
                    Text(
                        text = message.content,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            OutlinedButton(
                                onClick = onVisualize,
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp),
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, BrandPrimary.copy(alpha = 0.4f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = BrandPrimary)
                            ) {
                                Icon(imageVector = Icons.Default.Palette, contentDescription = null, modifier = Modifier.size(11.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("Visualize 🎨", fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = onTeachMe,
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary)
                            ) {
                                Icon(imageVector = Icons.Default.School, contentDescription = null, tint = Color.White, modifier = Modifier.size(11.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("Teach Me 🎓", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(message.content))
                                Toast.makeText(context, "Copied content Maawaaa! 📋", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy text",
                                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                modifier = Modifier.size(11.dp)
                            )
                        }
                    }
                }
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .padding(top = 4.dp)
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(BrandSecondary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "User",
                    tint = BrandSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
