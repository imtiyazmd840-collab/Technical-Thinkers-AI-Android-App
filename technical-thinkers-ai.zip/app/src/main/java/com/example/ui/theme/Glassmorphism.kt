package com.example.ui.theme

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun Modifier.glassCard(
    cornerRadius: Dp = 24.dp,
    borderWidth: Dp = 1.dp,
    elevation: Dp = 4.dp
): Modifier {
    val isDark = isSystemInDarkTheme()
    val baseColor = if (isDark) {
        Color(0xBC111A24) // Deep translucent dark (approx 74% opacity)
    } else {
        Color(0xCCFFFFFF) // Clean translucent white (80% opacity)
    }
    
    val borderColor = if (isDark) {
        Color(0x26FFFFFF) // Light glowing white border edge
    } else {
        Color(0x4DFFFFFF) // Glowing white border edge
    }

    val shadowColor = if (isDark) {
        Color(0x2A000000)
    } else {
        BrandPrimary.copy(alpha = 0.08f)
    }

    // Subtle slide-in and fade-in entry animation when the card enters the composition
    val animatedAlpha = remember { Animatable(0f) }
    val animatedOffsetY = remember { Animatable(45f) } // subtle offset in pixels (approx 15dp)

    LaunchedEffect(Unit) {
        animatedAlpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 450)
        )
    }

    LaunchedEffect(Unit) {
        animatedOffsetY.animateTo(
            targetValue = 0f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            )
        )
    }

    return this
        .graphicsLayer {
            alpha = animatedAlpha.value
            translationY = animatedOffsetY.value
        }
        .shadow(
            elevation = elevation,
            shape = RoundedCornerShape(cornerRadius),
            clip = false,
            ambientColor = shadowColor,
            spotColor = shadowColor
        )
        .clip(RoundedCornerShape(cornerRadius))
        .background(baseColor)
        .border(
            width = borderWidth,
            brush = Brush.verticalGradient(
                colors = listOf(
                    borderColor,
                    borderColor.copy(alpha = 0.2f)
                )
            ),
            shape = RoundedCornerShape(cornerRadius)
        )
}

@Composable
fun Modifier.glassChip(
    cornerRadius: Dp = 12.dp,
    borderWidth: Dp = 1.dp
): Modifier {
    val isDark = isSystemInDarkTheme()
    val baseColor = if (isDark) {
        Color(0x3DFFFFFF) // Thin transparent white
    } else {
        Color(0x14009EE0) // Thin transparent primary blue
    }
    
    val borderColor = if (isDark) {
        Color(0x1FFFFFFF)
    } else {
        BrandPrimary.copy(alpha = 0.15f)
    }

    return this
        .clip(RoundedCornerShape(cornerRadius))
        .background(baseColor)
        .border(
            width = borderWidth,
            color = borderColor,
            shape = RoundedCornerShape(cornerRadius)
        )
}
