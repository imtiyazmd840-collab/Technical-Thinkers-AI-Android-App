package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.glassCard
import com.example.ui.theme.glassChip
import com.example.ui.viewmodel.ChatViewModel

import com.example.ui.components.TechnicalThinkersLogo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: ChatViewModel,
    onNavigateToSettings: () -> Unit,
    onOpenDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val isDarkMode by viewModel.userPrefs.isDarkMode.collectAsState()
    val userGender by viewModel.userPrefs.userGender.collectAsState()

    var showAboutDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }

    val genderTitle = viewModel.userPrefs.getGenderTitle()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(imageVector = Icons.Default.Menu, contentDescription = "Open Drawer", tint = BrandPrimary)
                    }
                },
                title = {
                    Text(
                        text = "Profile",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings", tint = BrandPrimary)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Header / Avatar Card (Glassmorphic)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassCard(cornerRadius = 24.dp, elevation = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(BrandPrimary.copy(alpha = 0.15f), BrandSecondary.copy(alpha = 0.08f))
                            )
                        )
                        .padding(24.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Avatar placeholder with double border glow
                        Box(
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .background(BrandPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surface),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (userGender == "Male") Icons.Default.Face else if (userGender == "Female") Icons.Default.Face3 else Icons.Default.Person,
                                    contentDescription = "User Avatar",
                                    tint = BrandPrimary,
                                    modifier = Modifier.size(44.dp)
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Technical Thinker $genderTitle 👋",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Premium AI Explorer",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = BrandPrimary,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            }

            // GENDER SELECTOR CARD (Glassmorphic addressing customizer)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassCard(cornerRadius = 18.dp, elevation = 2.dp)
                    .padding(16.dp)
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "AI Addressing Mode",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = BrandPrimary
                    )
                    Text(
                        text = "Customize how TT AI calls you in conversations:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val genders = listOf("Male" to "Maawaaa 👦", "Female" to "Madammm 👧", "Unknown" to "Friend 🤝")
                        genders.forEach { (key, display) ->
                            val isSelected = userGender == key
                            Button(
                                onClick = { viewModel.userPrefs.setUserGender(key) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) BrandPrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                ),
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                  Text(display, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Profile Settings List (Glassmorphic)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassCard(cornerRadius = 18.dp, elevation = 2.dp)
                    .padding(vertical = 8.dp)
            ) {
                Column {
                    
                    // Dark Mode Toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.userPrefs.setDarkMode(!isDarkMode) }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Default.DarkMode else Icons.Default.LightMode,
                                contentDescription = "Dark Mode",
                                tint = BrandPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(
                                text = "Dark Theme",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = { viewModel.userPrefs.setDarkMode(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = BrandPrimary)
                        )
                    }

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                    // Share App
                    ProfileListItem(
                        icon = Icons.Default.Share,
                        title = "Share App",
                        onClick = { shareApp(context) }
                    )

                    // Rate App
                    ProfileListItem(
                        icon = Icons.Default.Star,
                        title = "Rate App",
                        onClick = { rateApp(context) }
                    )

                    // Contact
                    ProfileListItem(
                        icon = Icons.Default.Email,
                        title = "Contact Support",
                        onClick = { contactSupport(context) }
                    )

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                    // Privacy Policy
                    ProfileListItem(
                        icon = Icons.Default.Security,
                        title = "Privacy Policy",
                        onClick = { showPrivacyDialog = true }
                    )

                    // Terms
                    ProfileListItem(
                        icon = Icons.Default.Description,
                        title = "Terms & Conditions",
                        onClick = { showTermsDialog = true }
                    )

                    // About
                    ProfileListItem(
                        icon = Icons.Default.Info,
                        title = "About",
                        onClick = { showAboutDialog = true }
                    )
                }
            }

            // Developer Brand info at bottom
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TechnicalThinkersLogo(
                    modifier = Modifier.size(54.dp),
                    fallbackSize = 28.dp
                )
                Text(
                    text = "Technical Thinkers",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandPrimary
                )
                Text(
                    text = "Learn. Build. Grow. 🚀",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                )
                Text(
                    text = "App Version 1.0 (Production)",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                )
            }
        }
    }

    // ABOUT DIALOG
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TechnicalThinkersLogo(
                        modifier = Modifier.size(36.dp),
                        fallbackSize = 20.dp
                    )
                    Text("About Technical Thinkers AI", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Text(
                    "This is the official, premium AI assistant developed for Technical Thinkers. " +
                    "Designed with modern Material 3 components and powered by Gemini 3.5 Flash. " +
                    "Ask code, debug solutions, plan careers, or learn general knowledge speaking natural Tenglish! \n\n" +
                    "Developer: Technical Thinkers Team\nTagline: Learn. Build. Grow.",
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text("Super Maawaaa! 😄")
                }
            }
        )
    }

    // PRIVACY POLICY DIALOG
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy Policy", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Your privacy is our utmost priority. " +
                    "All chat histories are saved locally inside your device's offline Room Database. " +
                    "External API queries are secured directly with Google AI Studio backend services. " +
                    "We do not collect, share, or sell any of your personal queries.",
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text("I Understand")
                }
            }
        )
    }

    // TERMS DIALOG
    if (showTermsDialog) {
        AlertDialog(
            onDismissRequest = { showTermsDialog = false },
            title = { Text("Terms & Conditions", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "By using Technical Thinkers AI, you agree to: \n" +
                    "1. Use the AI responsibly for learning, coding, and growth.\n" +
                    "2. Avoid sending abusive language or malicious commands.\n" +
                    "3. Acknowledge that AI answers are for educational purposes, and medical/financial advice should be validated.\n\n" +
                    "Let's learn and build together!",
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showTermsDialog = false }) {
                    Text("Accept Terms")
                }
            }
        )
    }
}

@Composable
fun ProfileListItem(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = "Open",
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
            modifier = Modifier.size(18.dp)
        )
    }
}

private fun shareApp(context: Context) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Technical Thinkers AI App")
        putExtra(
            Intent.EXTRA_TEXT,
            "Hey Maawaaa! 🚀 Download the amazing Technical Thinkers AI Assistant App! It answers all coding, career, and tech questions in friendly Tenglish! Check it out: https://www.instagram.com/technical.thinkers"
        )
    }
    context.startActivity(Intent.createChooser(intent, "Share via"))
}

private fun rateApp(context: Context) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.aistudio.technicalthinkersai.ttai"))
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        // Fallback to web link if play store is not installed
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/technical.thinkers")))
    }
}

private fun contactSupport(context: Context) {
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("mailto:support@technicalthinkers.com")
        putExtra(Intent.EXTRA_SUBJECT, "Technical Thinkers AI - Support Request")
    }
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "No email clients found Maawaaa! 😅 Contact us at support@technicalthinkers.com", Toast.LENGTH_LONG).show()
    }
}
