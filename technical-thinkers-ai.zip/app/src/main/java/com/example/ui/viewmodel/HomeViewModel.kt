package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ChatSession
import com.example.data.local.UserPreferences
import com.example.data.repository.ChatRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val chatDao = AppDatabase.getDatabase(application).chatDao()
    private val repository = ChatRepository(chatDao)
    val userPrefs = UserPreferences(application)

    val latestSession: StateFlow<ChatSession?> = repository.latestSession
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Curated Motivation List
    private val motivations = listOf(
        "Code is like humor. When you have to explain it, it’s bad! Work hard, design clean, and grow Maawaaa! 💻🚀",
        "Success is not final, failure is not fatal: it is the courage to continue that counts! Keep building! 🌟💪",
        "The best way to predict the future is to invent it. Start writing your next app today! 🛠️🎨",
        "Learning never exhausts the mind. Ask TT AI anything and keep expanding your horizons Madammm! 🧠📖",
        "Don't worry if it doesn't work right. If everything did, you'd be out of a job! Play, debug, and learn! 😄🛠️"
    )

    // Curated Daily Facts
    private val dailyFacts = listOf(
        "AI Fact: The term 'Artificial Intelligence' was first coined in 1956 at the Dartmouth Summer Research Project! 🧠🌐",
        "Coding Fact: The first computer bug was a real physical moth found trapped inside a relay of the Harvard Mark II in 1947! 🦋💻",
        "Tech Fact: Over 90% of the world's currency exists only in digital form on servers, not physical paper! 💳💸",
        "Space Fact: Outer space is not completely silent; electromagnetic vibrations can be recorded and converted to sound waves by NASA! 🌌📡",
        "AI Fact: Neural Networks are loosely inspired by the structure of biological brains, but process info through mathematical matrices! 📊🤖"
    )

    // Curated Popular Questions
    val popularQuestions = listOf(
        "Explain quantum computing in Tenglish 🌌",
        "How to start learning Jetpack Compose? 📱",
        "Top 5 AI tools in 2026 for developers 🛠️",
        "Write a clean Kotlin coroutines example 💻",
        "Suggest a daily career checklist for engineers 📈",
        "Explain recursion with a funny joke 😆"
    )

    // Curated Trending Topics
    val trendingTopics = listOf(
        "Jetpack Compose 1.8 & Edge-To-Edge 📱",
        "Generative Models (Gemini 3.5 Flash) 🤖",
        "Kotlin Multiplatform (KMP) Adoption 🌐",
        "On-device AI & Nano Models 🧠",
        "Robolectric Unit Testing in JVM 🧪"
    )

    // Curated Daily Tech & Programming Tips
    private val techTips = listOf(
        "Use Destructuring in Kotlin: You can destructure objects in Kotlin to assign multiple variables directly, e.g., val (id, name) = user. Extremely useful for pairs, triples, and data classes! 🧩✨",
        "Prefer val over var: Keep your data immutable by default! Immutable state prevents side effects, makes concurrent programming safer, and leads to cleaner, self-documenting code. 🛡️🔒",
        "Master Jetpack Compose state: Use rememberSaveable instead of remember if you want your UI state to survive activity recreation, like orientation changes or low-memory process death! 📱🔄",
        "Optimize Kotlin loops with Sequences: If you are chaining multiple operations like filter and map on large collections, use .asSequence() first to evaluate elements lazily and avoid creating intermediate copies! 🚀⚡",
        "Coroutine Dispatchers: Never run heavy CPU calculations or I/O operations on Dispatchers.Main! Use Dispatchers.IO for networking/database operations and Dispatchers.Default for CPU-intensive tasks. 🧵⚙️",
        "The Power of let, run, with, apply, and also: Master these scoping functions to make your code more elegant. Use 'apply' to initialize object properties and 'also' for side-effect operations like logging! 💡🛠️",
        "Room Database Performance: Always access your database asynchronously using Kotlin Coroutines or Flow. Use indices on columns that you query frequently to speed up database lookups! 🗄️🔍",
        "Clean Code - The Boy Scout Rule: Always leave the playground cleaner than you found it. Refactor a tiny bit of messy code every time you work on a file to prevent technical debt build-up! 🧹💚",
        "Don't Repeat Yourself (DRY): If you find yourself copy-pasting code, extract it into a reusable helper function or custom Composable. But remember, a little duplication is sometimes better than the wrong abstraction! ♻️📐"
    )

    private val _currentMotivation = MutableStateFlow("")
    val currentMotivation: StateFlow<String> = _currentMotivation.asStateFlow()

    private val _currentFact = MutableStateFlow("")
    val currentFact: StateFlow<String> = _currentFact.asStateFlow()

    private val _currentTechTip = MutableStateFlow("")
    val currentTechTip: StateFlow<String> = _currentTechTip.asStateFlow()

    init {
        rotateDailyContent()
    }

    fun rotateDailyContent() {
        val random = Random(System.currentTimeMillis())
        _currentMotivation.value = motivations[random.nextInt(motivations.size)]
        _currentFact.value = dailyFacts[random.nextInt(dailyFacts.size)]
        _currentTechTip.value = techTips[random.nextInt(techTips.size)]
    }
}
