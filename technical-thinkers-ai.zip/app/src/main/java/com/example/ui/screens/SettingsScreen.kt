package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.glassCard
import com.example.ui.theme.glassChip
import com.example.ui.viewmodel.ChatViewModel

import com.example.ui.components.TechnicalThinkersLogo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: ChatViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val clipboardManager = LocalClipboardManager.current

    val isDarkMode by viewModel.userPrefs.isDarkMode.collectAsState()
    val isNotificationsEnabled by viewModel.userPrefs.isNotificationsEnabled.collectAsState()
    val currentSessionId by viewModel.currentSessionId.collectAsState()
    val currentMessages by viewModel.currentMessages.collectAsState()

    var showClearConfirm by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val genderTitle = viewModel.userPrefs.getGenderTitle()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    Box(modifier = Modifier.padding(end = 12.dp)) {
                        TechnicalThinkersLogo(
                            modifier = Modifier.size(32.dp),
                            fallbackSize = 20.dp
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            
            // PREFERENCES SECTION
            Text(
                text = "Preferences",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = BrandPrimary,
                modifier = Modifier.padding(start = 4.dp)
            )

            // Glassmorphic Preferences Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassCard(cornerRadius = 18.dp, elevation = 2.dp)
            ) {
                Column {
                    // Theme Selector Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.userPrefs.setDarkMode(!isDarkMode) }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isDarkMode) Icons.Default.DarkMode else Icons.Default.LightMode,
                                contentDescription = "Theme",
                                tint = BrandPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = "Dark Mode",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Reduce eye strain at night",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                        }
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = { viewModel.userPrefs.setDarkMode(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = BrandPrimary)
                        )
                    }

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                    // Notifications Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.userPrefs.setNotificationsEnabled(!isNotificationsEnabled) }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isNotificationsEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                                contentDescription = "Notifications",
                                tint = BrandPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = "Push Notifications",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Stay updated with daily facts & tips",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                        }
                        Switch(
                            checked = isNotificationsEnabled,
                            onCheckedChange = { viewModel.userPrefs.setNotificationsEnabled(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = BrandPrimary)
                        )
                    }
                }
            }

            // CHAT MANAGEMENT SECTION
            Text(
                text = "Chat Management",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = BrandPrimary,
                modifier = Modifier.padding(start = 4.dp, top = 8.dp)
            )

            // Glassmorphic Chat Management Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassCard(cornerRadius = 18.dp, elevation = 2.dp)
            ) {
                Column {
                    // Export Chat
                    SettingsListItem(
                        icon = Icons.Default.Share,
                        title = "Export Current Chat",
                        subtitle = "Copy active conversation history log",
                        onClick = {
                            val log = viewModel.exportChatHistory()
                            clipboardManager.setText(AnnotatedString(log))
                            Toast.makeText(context, "Chat history copied to clipboard Maawaaa! 📋", Toast.LENGTH_LONG).show()
                        }
                    )

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                    // Clear Chat
                    SettingsListItem(
                        icon = Icons.Default.ClearAll,
                        title = "Clear Current Chat Messages",
                        subtitle = "Wipes messages but keeps the active thread",
                        onClick = {
                            if (currentSessionId == null) {
                                Toast.makeText(context, "No active chat to clear, $genderTitle! 😅", Toast.LENGTH_SHORT).show()
                            } else {
                                showClearConfirm = true
                            }
                        }
                    )

                    Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))

                    // Delete Chat
                    SettingsListItem(
                        icon = Icons.Default.DeleteForever,
                        title = "Delete Chat Thread",
                        subtitle = "Completely remove the active conversation",
                        color = MaterialTheme.colorScheme.error,
                        onClick = {
                            if (currentSessionId == null) {
                                Toast.makeText(context, "No active chat to delete, $genderTitle! 😅", Toast.LENGTH_SHORT).show()
                            } else {
                                showDeleteConfirm = true
                            }
                        }
                    )
                }
            }
        }
    }

    // CONFIRM DIALOGS
    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear Chat Messages?", fontWeight = FontWeight.Bold) },
            text = { Text("Malli recover cheyalem Maawaaa! Are you sure you want to clear all messages in this conversation?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearCurrentSession()
                        showClearConfirm = false
                        Toast.makeText(context, "Chat cleared successfully! 🧼", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Clear All", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Entire Chat Thread?", fontWeight = FontWeight.Bold) },
            text = { Text("Ee convo motham database nundi delete aypothundi Madammm! Sure ga delete cheyalantara?") },
            confirmButton = {
                Button(
                    onClick = {
                        currentSessionId?.let { viewModel.deleteSession(it) }
                        showDeleteConfirm = false
                        Toast.makeText(context, "Chat thread deleted! 🗑️", Toast.LENGTH_SHORT).show()
                        onBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SettingsListItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    color: Color = MaterialTheme.colorScheme.onSurface,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (color == MaterialTheme.colorScheme.error) color.copy(alpha = 0.1f) else BrandPrimary.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (color == MaterialTheme.colorScheme.error) color else BrandPrimary,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = color
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = "Open",
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
            modifier = Modifier.size(18.dp)
        )
    }
}
