package com.example.ui.components

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.remote.EducationalVisual
import com.example.data.remote.VisualEdge
import com.example.data.remote.VisualNode
import com.example.data.remote.VisualType
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import java.io.OutputStream
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InteractiveVisualizer(
    visual: EducationalVisual,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var selectedNode by remember { mutableStateOf<VisualNode?>(null) }
    
    // Capture-ready composable container
    var composeViewToCapture by remember { mutableStateOf<View?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Bar
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = visual.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Visualization: ${visual.type.name}",
                        style = MaterialTheme.typography.bodySmall,
                        color = BrandPrimary
                    )
                }
            },
            navigationIcon = {
                IconButton(onClick = onClose) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            },
            actions = {
                IconButton(onClick = {
                    // Reset zoom/pan
                    scale = 1f
                    offset = Offset.Zero
                    selectedNode = null
                }) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset Zoom")
                }
                IconButton(onClick = {
                    composeViewToCapture?.let { view ->
                        saveViewAsImage(context, view, visual.title)
                    } ?: run {
                        Toast.makeText(context, "Visual is preparing, please tap again!", Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Icon(imageVector = Icons.Default.Download, contentDescription = "Download Diagram")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )
        )

        // Main Diagram Canvas & Node Renderer
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 64.dp, bottom = 120.dp)
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.5f, 4.0f)
                        offset += pan
                    }
                }
        ) {
            // AndroidView container to allow Bitmap capture of Jetpack Compose content
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    ComposeView(ctx).apply {
                        composeViewToCapture = this
                        setContent {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(MaterialTheme.colorScheme.background)
                            ) {
                                DiagramRenderer(
                                    visual = visual,
                                    scale = scale,
                                    offset = offset,
                                    selectedNode = selectedNode,
                                    onNodeSelected = { selectedNode = it }
                                )
                            }
                        }
                    }
                }
            )

            // Zoom Indicator
            Box(
                modifier = Modifier
                    .padding(16.dp)
                    .align(Alignment.TopEnd)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${(scale * 100).toInt()}% Zoom",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandPrimary
                )
            }
        }

        // Floating Interactive Info Panel & Explanation Panel
        AnimatedVisibility(
            visible = true,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                        RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                    ),
                tonalElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (selectedNode != null) {
                        // Node Specific details
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(BrandPrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = getNodeIcon(visual.type, selectedNode!!.type),
                                    contentDescription = null,
                                    tint = BrandPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                            Text(
                                text = selectedNode!!.label,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = BrandPrimary
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            IconButton(
                                onClick = { selectedNode = null },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear Selection",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Text(
                            text = selectedNode!!.description ?: "Interactive element containing topic data details.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    } else {
                        // Overall Tenglish explanation matching the image
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = BrandPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Mawaa! Concept Explanation",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = BrandPrimary
                            )
                        }

                        Text(
                            text = visual.explanationInTenglish,
                            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        if (visual.annotations.isNotEmpty()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                visual.annotations.take(3).forEach { annotation ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = annotation,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DiagramRenderer(
    visual: EducationalVisual,
    scale: Float,
    offset: Offset,
    selectedNode: VisualNode?,
    onNodeSelected: (VisualNode) -> Unit
) {
    val nodeColor = BrandPrimary
    val edgeColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer(
                scaleX = scale,
                scaleY = scale,
                translationX = offset.x,
                translationY = offset.y
            )
    ) {
        // 1. Draw Edges (Lines/Arrows) on Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            visual.edges.forEach { edge ->
                val fromNode = visual.nodes.find { it.id == edge.from }
                val toNode = visual.nodes.find { it.id == edge.to }

                if (fromNode != null && toNode != null) {
                    val startX = (fromNode.x / 100f) * width
                    val startY = (fromNode.y / 100f) * height
                    val endX = (toNode.x / 100f) * width
                    val endY = (toNode.y / 100f) * height

                    val start = Offset(startX, startY)
                    val end = Offset(endX, endY)

                    // Draw connection line
                    if (edge.style == "dashed") {
                        drawDashedLine(
                            start = start,
                            end = end,
                            color = edgeColor,
                            strokeWidth = 2f
                        )
                    } else {
                        drawLine(
                            start = start,
                            end = end,
                            color = edgeColor,
                            strokeWidth = 3f,
                            cap = StrokeCap.Round
                        )
                    }

                    // Draw directed arrow head if applicable
                    if (edge.isDirected) {
                        drawArrowHead(
                            start = start,
                            end = end,
                            color = edgeColor
                        )
                    }

                    // Optional Edge Label text
                    if (!edge.label.isNullOrEmpty()) {
                        val midX = (startX + endX) / 2f
                        val midY = (startY + endY) / 2f
                        drawContext.canvas.nativeCanvas.drawText(
                            edge.label,
                            midX,
                            midY - 10f,
                            android.graphics.Paint().apply {
                                color = android.graphics.Color.GRAY
                                textSize = 24f
                                textAlign = android.graphics.Paint.Align.CENTER
                                isFakeBoldText = true
                            }
                        )
                    }
                }
            }

            // Draw Solar orbits if applicable
            if (visual.type == VisualType.SOLAR_SYSTEM) {
                drawCircle(
                    color = BrandPrimary.copy(alpha = 0.08f),
                    radius = width * 0.18f,
                    center = Offset(width * 0.5f, height * 0.5f),
                    style = Stroke(width = 2f, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                )
                drawCircle(
                    color = BrandSecondary.copy(alpha = 0.08f),
                    radius = width * 0.32f,
                    center = Offset(width * 0.5f, height * 0.5f),
                    style = Stroke(width = 2f, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f))
                )
            }
        }

        // 2. Draw Interactive Nodes as composables layered on top
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val width = maxWidth
            val height = maxHeight

            visual.nodes.forEach { node ->
                val xDp = width * (node.x / 100f)
                val yDp = height * (node.y / 100f)

                val isSelected = selectedNode?.id == node.id
                val shapeStyle = if (visual.type == VisualType.FLOWCHART && node.id == "start") RoundedCornerShape(24.dp) else RoundedCornerShape(12.dp)

                Box(
                    modifier = Modifier
                        .offset(x = xDp - 50.dp, y = yDp - 30.dp) // center the 100x60 node Box
                        .size(width = 100.dp, height = 65.dp)
                        .shadow(if (isSelected) 8.dp else 2.dp, shapeStyle)
                        .clip(shapeStyle)
                        .background(
                            if (isSelected) Brush.verticalGradient(listOf(BrandPrimary, BrandPrimary.copy(alpha = 0.8f)))
                            else Brush.verticalGradient(
                                listOf(
                                    MaterialTheme.colorScheme.surface,
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                )
                            )
                        )
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) Color.Transparent else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                            shape = shapeStyle
                        )
                        .clickable { onNodeSelected(node) }
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = getNodeIcon(visual.type, node.type),
                            contentDescription = null,
                            tint = if (isSelected) Color.White else BrandPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = node.label,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 10.sp
                        )
                    }
                }
            }
        }
    }
}

// Arrow drawing helper
fun androidx.compose.ui.graphics.drawscope.DrawScope.drawArrowHead(
    start: Offset,
    end: Offset,
    color: Color
) {
    val arrowSize = 14f
    val dx = end.x - start.x
    val dy = end.y - start.y
    val angle = atan2(dy, dx)

    // Calculate position shortly before the end node so the arrowhead doesn't disappear under the card
    val distance = Offset(dx, dy).getDistance()
    if (distance < 50f) return // avoid tiny calculations
    
    val arrowTipX = end.x - 38f * cos(angle) // offset to stop near the card border
    val arrowTipY = end.y - 38f * sin(angle)

    val path = Path().apply {
        moveTo(arrowTipX, arrowTipY)
        lineTo(
            arrowTipX - arrowSize * cos(angle - Math.PI / 6).toFloat(),
            arrowTipY - arrowSize * sin(angle - Math.PI / 6).toFloat()
        )
        lineTo(
            arrowTipX - arrowSize * cos(angle + Math.PI / 6).toFloat(),
            arrowTipY - arrowSize * sin(angle + Math.PI / 6).toFloat()
        )
        close()
    }
    drawPath(path = path, color = color)
}

// Dashed Line Helper
fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDashedLine(
    start: Offset,
    end: Offset,
    color: Color,
    strokeWidth: Float
) {
    val intervals = floatArrayOf(15f, 10f)
    drawLine(
        color = color,
        start = start,
        end = end,
        strokeWidth = strokeWidth,
        pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(intervals, 0f)
    )
}

// Icon getter based on visualization types
fun getNodeIcon(visualType: VisualType, nodeType: String): ImageVector {
    val lowerType = nodeType.lowercase()
    return when (visualType) {
        VisualType.SOLAR_SYSTEM -> {
            if (lowerType.contains("star") || lowerType.contains("sun")) Icons.Default.WbSunny
            else Icons.Default.Public
        }
        VisualType.NETWORK_TOPOLOGY -> {
            if (lowerType.contains("client") || lowerType.contains("phone") || lowerType.contains("device")) Icons.Default.Smartphone
            else if (lowerType.contains("router") || lowerType.contains("api")) Icons.Default.Router
            else if (lowerType.contains("db") || lowerType.contains("database")) Icons.Default.Storage
            else Icons.Default.Dns
        }
        VisualType.CHEMISTRY_MOLECULE -> {
            if (lowerType.contains("atom") || lowerType.contains("hydrogen")) Icons.Default.Circle
            else Icons.Default.Science
        }
        VisualType.FLOWCHART -> {
            if (lowerType.contains("start") || lowerType.contains("end")) Icons.Default.PlayArrow
            else Icons.Default.Assessment
        }
        VisualType.MATH_GRAPH -> Icons.Default.ShowChart
        VisualType.TIMELINE -> Icons.Default.Schedule
        VisualType.LABELED_ANATOMY -> Icons.Default.Favorite
        VisualType.BINARY_TREE -> Icons.Default.AccountTree
        else -> Icons.Default.AutoAwesome
    }
}

// Core high-quality screenshot / download utility
fun saveViewAsImage(context: Context, view: View, title: String) {
    try {
        // Create screenshot bitmap
        val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        view.draw(canvas)

        val filename = "TT_Visual_${title.replace("[^a-zA-Z0-9]".toRegex(), "_")}_${System.currentTimeMillis()}.png"
        var outputStream: OutputStream? = null

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/TechnicalThinkers")
            }
            val imageUri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            if (imageUri != null) {
                outputStream = context.contentResolver.openOutputStream(imageUri)
            }
        } else {
            val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()
            val file = java.io.File(imagesDir, filename)
            outputStream = java.io.FileOutputStream(file)
        }

        outputStream?.use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            Toast.makeText(context, "Mawa! Diagram standard gallery lo save ayyindi! 🚀", Toast.LENGTH_LONG).show()
        }
    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(context, "Oh no, save cheyyadam lo failed! Try again: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}
