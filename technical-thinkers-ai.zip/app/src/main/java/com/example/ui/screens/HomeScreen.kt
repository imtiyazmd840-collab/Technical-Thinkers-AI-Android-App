package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.glassCard
import com.example.ui.theme.glassChip
import com.example.ui.viewmodel.HomeViewModel

import com.example.ui.components.TechnicalThinkersLogo
import androidx.compose.material.icons.filled.Menu

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToChat: (String?) -> Unit,
    onNavigateToChatWithPrompt: (String) -> Unit,
    onOpenDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val latestSession by viewModel.latestSession.collectAsState()
    val motivation by viewModel.currentMotivation.collectAsState()
    val fact by viewModel.currentFact.collectAsState()
    val techTip by viewModel.currentTechTip.collectAsState()

    val suggestions = listOf("AI 🤖", "Coding 💻", "Career 📈", "Apps 📱", "Technology 🌐", "GK 🧠", "Fun 😆")

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Open Drawer",
                            tint = BrandPrimary
                        )
                    }
                },
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        TechnicalThinkersLogo(
                            modifier = Modifier.size(32.dp),
                            fallbackSize = 20.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Technical Thinkers AI",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            ),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Animated Entrance
            AnimatedVisibility(
                visible = true,
                enter = fadeIn() + slideInVertically(initialOffsetY = { 40 })
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    
                    // Welcome Gradient Card (Glassmorphic)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("welcome_card")
                            .glassCard(cornerRadius = 24.dp)
                            .background(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        BrandPrimary.copy(alpha = 0.15f),
                                        BrandSecondary.copy(alpha = 0.08f)
                                    ),
                                    start = Offset(0f, 0f),
                                    end = Offset(1000f, 1000f)
                                )
                            )
                            .padding(24.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "Hi 👋",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "Welcome to Technical Thinkers AI",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f)
                            )
                            Text(
                                text = "Cheppu ivvala em nerchukundam anukuntunav? 😄",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f)
                            )
                            
                            Button(
                                onClick = { onNavigateToChat(null) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BrandPrimary,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .padding(top = 8.dp)
                                    .testTag("start_chat_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ChatBubble,
                                    contentDescription = "Chat",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Start AI Chat", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Horizontal Suggestion Chips
                    Text(
                        text = "Explore suggestions:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(suggestions) { suggestion ->
                            Box(
                                modifier = Modifier
                                    .glassChip()
                                    .clickable { onNavigateToChatWithPrompt("Naku $suggestion gurinchi details kavali Maawaaa! 📚") }
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = suggestion,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }

                    // Continue Last Chat Card (Glassmorphic)
                    latestSession?.let { session ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("continue_chat_card")
                                .glassCard(elevation = 2.dp)
                                .clickable { onNavigateToChat(session.id) }
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.History,
                                        contentDescription = "History",
                                        tint = BrandPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "Continue Last Chat",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = BrandPrimary
                                        )
                                        Text(
                                            text = session.title,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowForwardIos,
                                    contentDescription = "Go",
                                    tint = BrandPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    // Beautiful AI Vector Drawing Illustration (Compose Canvas)
                    // Beautiful AI Vector Drawing Illustration (Glassmorphic)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .glassCard(elevation = 1.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val width = size.width
                            val height = size.height

                            // Draw gradient background grid lines
                            for (i in 0..10) {
                                val x = i * (width / 10f)
                                drawLine(
                                    color = BrandPrimary.copy(alpha = 0.05f),
                                    start = Offset(x, 0f),
                                    end = Offset(x, height),
                                    strokeWidth = 1.dp.toPx()
                                )
                            }
                            for (i in 0..5) {
                                val y = i * (height / 5f)
                                drawLine(
                                    color = BrandPrimary.copy(alpha = 0.05f),
                                    start = Offset(0f, y),
                                    end = Offset(width, y),
                                    strokeWidth = 1.dp.toPx()
                                )
                            }

                            // Glowing neural core circles
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(BrandPrimary.copy(alpha = 0.3f), Color.Transparent),
                                    center = Offset(width / 2f, height / 2f),
                                    radius = 80.dp.toPx()
                                ),
                                radius = 80.dp.toPx(),
                                center = Offset(width / 2f, height / 2f)
                            )

                            // Digital brain tech nodes
                            val nodes = listOf(
                                Offset(width / 2f, height / 2f), // Center
                                Offset(width / 2f - 100f, height / 2f - 80f),
                                Offset(width / 2f + 100f, height / 2f - 80f),
                                Offset(width / 2f - 140f, height / 2f + 60f),
                                Offset(width / 2f + 140f, height / 2f + 60f),
                                Offset(width / 2f, height / 2f + 100f)
                            )

                            // Connect nodes with light lines
                            for (j in 1 until nodes.size) {
                                drawLine(
                                    color = BrandPrimary.copy(alpha = 0.4f),
                                    start = nodes[0],
                                    end = nodes[j],
                                    strokeWidth = 2.dp.toPx()
                                )
                            }

                            // Outer tech orbits
                            drawCircle(
                                color = BrandSecondary.copy(alpha = 0.2f),
                                radius = 50.dp.toPx(),
                                center = Offset(width / 2f, height / 2f),
                                style = Stroke(width = 1.5.dp.toPx())
                            )

                            // Draw glowing points
                            for (node in nodes) {
                                drawCircle(
                                    color = BrandSecondary,
                                    radius = 6.dp.toPx(),
                                    center = node
                                )
                                drawCircle(
                                    color = Color.White,
                                    radius = 2.dp.toPx(),
                                    center = node
                                )
                            }
                        }

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = "Technical Thinkers AI Core",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = BrandPrimary
                            )
                            Text(
                                text = "Your personal Tenglish assistant is online",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                            )
                        }
                    }

                    // Today's Motivation Card (Glassmorphic)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("motivation_card")
                            .glassCard(elevation = 2.dp)
                            .padding(20.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = "Quote",
                                    tint = BrandSecondary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Today's Motivation",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = BrandSecondary
                                )
                            }
                            Text(
                                text = motivation,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 20.sp
                            )
                        }
                    }

                    // Daily Fact Card (Glassmorphic)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("fact_card")
                            .glassCard(elevation = 2.dp)
                            .padding(20.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "Fact",
                                    tint = BrandPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Daily AI & Tech Fact",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = BrandPrimary
                                )
                            }
                            Text(
                                text = fact,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 20.sp
                            )
                        }
                    }

                    // Daily Tech Tip Card (Glassmorphic)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tech_tip_card")
                            .glassCard(elevation = 2.dp)
                            .padding(20.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Code,
                                        contentDescription = "Tech Tip",
                                        tint = BrandSecondary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Daily Tech Tip",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = BrandSecondary
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.rotateDailyContent() },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Refresh Tip",
                                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Text(
                                text = techTip,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 20.sp
                            )

                            Button(
                                onClick = { onNavigateToChatWithPrompt("Naku ee Daily Tech Tip gurinchi clear ga explain chey Maawaaa! 🧠\n\nTip: $techTip") },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BrandPrimary.copy(alpha = 0.15f),
                                    contentColor = BrandPrimary
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .fillMaxWidth()
                                    .testTag("ask_ai_tip_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = "Ask AI",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Ask TT AI to explain this 🧠", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }

                    // Popular Questions (Glassmorphic)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .glassCard(elevation = 2.dp)
                            .padding(16.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "Popular Questions Maawaaa",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                            viewModel.popularQuestions.forEach { question ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { onNavigateToChatWithPrompt(question) }
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = question,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = "Ask",
                                        tint = BrandPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Trending Topics (Glassmorphic)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .glassCard(elevation = 2.dp)
                            .padding(16.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "Trending Tech Topics 🚀",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                            viewModel.trendingTopics.forEachIndexed { index, topic ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(BrandPrimary.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${index + 1}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = BrandPrimary
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = topic,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
