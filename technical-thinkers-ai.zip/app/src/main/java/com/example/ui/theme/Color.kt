package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BrandPrimary = Color(0xFF009EE0)
val BrandSecondary = Color(0xFF00B0FF)
val BrandTertiary = Color(0xFF0C131A)

val LightBackground = Color(0xFFF3F8FB)
val LightSurface = Color(0xFFFFFFFF)
val LightOnBackground = Color(0xFF111A24)
val LightOnSurface = Color(0xFF111A24)

val DarkBackground = Color(0xFF0C131A)
val DarkSurface = Color(0xFF16222F)
val DarkOnBackground = Color(0xFFECEFF1)
val DarkOnSurface = Color(0xFFECEFF1)
