package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.BuildConfig
import com.example.data.remote.Content
import com.example.data.remote.GenerateContentRequest
import com.example.data.remote.Part
import com.example.data.remote.RetrofitClient
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.viewmodel.ChatViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

enum class VoiceState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}

@Composable
fun LiveVoiceOverlay(
    viewModel: ChatViewModel,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var voiceState by remember { mutableStateOf(VoiceState.IDLE) }
    var userTranscription by remember { mutableStateOf("") }
    var aiVocalResponse by remember { mutableStateOf("") }
    var dbStatusText by remember { mutableStateOf("Mawa! Microphones on, say something!") }

    // TTS & STT instances
    var textToSpeech by remember { mutableStateOf<TextToSpeech?>(null) }
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    val speechIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN") // Optimal English/Telugu blended recognition
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
    }

    // Helper functions
    val stopAllSpeech = {
        try {
            textToSpeech?.stop()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    val speakResponse = { text: String ->
        stopAllSpeech()
        voiceState = VoiceState.SPEAKING
        aiVocalResponse = text
        dbStatusText = "Mawa, speaking..."
        
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "TTAI_VOICE_MODE")
        }
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "TTAI_VOICE_MODE")
    }

    // Initialize STT speech recognizer
    val startListeningSTT = {
        try {
            stopAllSpeech()
            voiceState = VoiceState.LISTENING
            userTranscription = ""
            dbStatusText = "Mawa! Listening to you..."
            speechRecognizer?.startListening(speechIntent)
        } catch (e: Exception) {
            e.printStackTrace()
            voiceState = VoiceState.ERROR
            dbStatusText = "STT Error: ${e.localizedMessage}"
        }
    }

    // Call Gemini for Voice mode response
    val generateVoiceResponse = { userPrompt: String ->
        voiceState = VoiceState.THINKING
        dbStatusText = "Thinking..."
        coroutineScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                    speakResponse("Ayyoo Maawaaa! API Key ledhu! AI Studio Settings lo ledha Secrets panel lo 'GEMINI_API_KEY' add cheyyi. Appudu nenu ready ga mawa!")
                    return@launch
                }

                // Call Gemini using repository system instructions to get natural Tenglish response
                val gender = viewModel.userPrefs.userGender.value
                val systemInstructionText = """
                    You are TT AI, the official premium voice assistant of Technical Thinkers.
                    Speak naturally in super-friendly, energetic, warm Tenglish (a lively mix of Telugu and English using English letters).
                    Address the user as:
                    - If Male: 'Mawaa' (e.g. 'Cheppu Mawaa', 'Super Mawaa', 'Ela unnav Mawaa?')
                    - If Female: 'Madammm' (e.g. 'Cheppu Madammm', 'Ela unnar Madammm?')
                    - Otherwise: 'Friend'
                    Keep responses very short, conversational, and energetic. Max 2-3 brief sentences so it sounds natural in speech.
                """.trimIndent()

                val request = GenerateContentRequest(
                    contents = listOf(
                        Content(
                            role = "user",
                            parts = listOf(Part(text = userPrompt))
                        )
                    ),
                    systemInstruction = Content(
                        parts = listOf(Part(text = systemInstructionText))
                    )
                )

                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.service.generateContent(
                        model = "gemini-3.5-flash",
                        apiKey = apiKey,
                        request = request
                    )
                }

                val resultText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: "Mawaa! Emo response khali ga vachindi, malli adugu!"

                speakResponse(resultText)

            } catch (e: Exception) {
                e.printStackTrace()
                speakResponse("Ayyoo Mawaa! Chinna problem vachindi! Network check chesko ledha koddiga aagi try cheyyi.")
            }
        }
    }

    // Setup TextToSpeech
    LaunchedEffect(Unit) {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.let { tts ->
                    tts.language = Locale.ENGLISH
                    tts.setPitch(1.15f) // Energetic and friendly
                    tts.setSpeechRate(0.95f) // Natural tempo
                    
                    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            Log.d("VoiceMode", "TTS playing started")
                        }

                        override fun onDone(utteranceId: String?) {
                            // Automatically start listening again for next input (hands-free!)
                            coroutineScope.launch {
                                startListeningSTT()
                            }
                        }

                        override fun onError(utteranceId: String?) {
                            Log.e("VoiceMode", "TTS error")
                        }
                    })
                }
                
                // Greet immediately
                val genderTitle = viewModel.userPrefs.getGenderTitle()
                speakResponse("Hi $genderTitle! Welcome back. AI voice mode ready! Cheppu, em nerchukundham eeroju? 🚀")
            } else {
                Log.e("VoiceMode", "TTS initialization failed")
                voiceState = VoiceState.ERROR
                dbStatusText = "TTS initialization failed!"
            }
        }

        // Setup SpeechRecognizer
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                
                override fun onError(error: Int) {
                    val message = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                        SpeechRecognizer.ERROR_CLIENT -> "Client side error"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permissions missing"
                        SpeechRecognizer.ERROR_NETWORK -> "Network connection error"
                        SpeechRecognizer.ERROR_NO_MATCH -> "No speech matching found"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "STT active"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Silence timeout"
                        else -> "Speech recognizer error"
                    }
                    Log.e("VoiceMode", "STT Error: $message")
                    
                    // Fall back gracefully or restart if silent timeout
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        dbStatusText = "Mawa! Em analedha? Say something!"
                        voiceState = VoiceState.IDLE
                    } else {
                        voiceState = VoiceState.ERROR
                        dbStatusText = message
                    }
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val input = matches[0]
                        userTranscription = input
                        dbStatusText = "User: $input"
                        generateVoiceResponse(input)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        userTranscription = matches[0]
                        dbStatusText = "Listening: ${matches[0]}..."
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    // Clean up instances on exit
    DisposableEffect(Unit) {
        onDispose {
            try {
                textToSpeech?.stop()
                textToSpeech?.shutdown()
                speechRecognizer?.stopListening()
                speechRecognizer?.destroy()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // UI Animations
    val infiniteTransition = rememberInfiniteTransition(label = "voice_glow")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val waveHeight1 by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 90f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave1"
    )
    val waveHeight2 by infiniteTransition.animateFloat(
        initialValue = 25f,
        targetValue = 65f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave2"
    )
    val waveHeight3 by infiniteTransition.animateFloat(
        initialValue = 15f,
        targetValue = 105f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave3"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0D0E15).copy(alpha = 0.96f)), // Rich space dark obsidian
        contentAlignment = Alignment.Center
    ) {
        // Exit voice mode
        IconButton(
            onClick = {
                stopAllSpeech()
                onClose()
            },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(24.dp)
                .size(48.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.1f))
        ) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close Voice Mode", tint = Color.White)
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(36.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            // Screen Header title
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF4CAF50)))
                    Text(
                        text = "Technical Thinkers Live Voice",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 0.5.sp
                    )
                }
                Text(
                    text = "Hands-free continuous conversation 🎙️",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.5f)
                )
            }

            // Animated Visual Waveform or Speaking Face
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                BrandPrimary.copy(alpha = 0.15f),
                                Color.Transparent
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Wave pulsing background
                Box(
                    modifier = Modifier
                        .size(160.dp * if (voiceState == VoiceState.LISTENING || voiceState == VoiceState.SPEAKING) pulseScale else 1f)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    BrandPrimary.copy(alpha = 0.15f),
                                    BrandSecondary.copy(alpha = 0.1f)
                                )
                            )
                        )
                )

                // Central Active Status Controller Button
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .shadow(12.dp, CircleShape)
                        .clip(CircleShape)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(BrandPrimary, BrandSecondary)
                            )
                        )
                        .clickable {
                            if (voiceState == VoiceState.SPEAKING || voiceState == VoiceState.THINKING) {
                                stopAllSpeech()
                                startListeningSTT()
                            } else if (voiceState == VoiceState.LISTENING) {
                                speechRecognizer?.stopListening()
                                voiceState = VoiceState.IDLE
                                dbStatusText = "Voice paused."
                            } else {
                                startListeningSTT()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    val statusIcon = when (voiceState) {
                        VoiceState.LISTENING -> Icons.Default.Mic
                        VoiceState.THINKING -> Icons.Default.HourglassEmpty
                        VoiceState.SPEAKING -> Icons.Default.VolumeUp
                        else -> Icons.Default.MicNone
                    }
                    Icon(
                        imageVector = statusIcon,
                        contentDescription = "Microphone Button",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            // Dynamic Dancing Waves Visualizer
            AnimatedVisibility(
                visible = voiceState == VoiceState.LISTENING || voiceState == VoiceState.SPEAKING,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut()
            ) {
                Row(
                    modifier = Modifier
                        .width(180.dp)
                        .height(80.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val heights = listOf(waveHeight1, waveHeight2, waveHeight3, waveHeight2, waveHeight1)
                    heights.forEachIndexed { idx, heightVal ->
                        val barColor = if (idx % 2 == 0) BrandPrimary else BrandSecondary
                        Box(
                            modifier = Modifier
                                .width(6.dp)
                                .height(heightVal.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(barColor)
                        )
                    }
                }
            }

            // Floating transcript captions
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                // Status description
                Text(
                    text = dbStatusText,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandPrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Transcription block
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.05f))
                        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = when (voiceState) {
                            VoiceState.LISTENING -> if (userTranscription.isEmpty()) "Say something..." else userTranscription
                            VoiceState.SPEAKING -> aiVocalResponse
                            VoiceState.THINKING -> "TT AI processing thoughts..."
                            VoiceState.ERROR -> "Ayyoo, voice microphone problem vachindi! Tapping again to speak."
                            else -> "Tap the microphone to start talking naturally!"
                        },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White.copy(alpha = 0.85f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }
            }
        }
    }
}
