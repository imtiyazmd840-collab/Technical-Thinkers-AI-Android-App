package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessage
import com.example.data.local.ChatSession
import com.example.data.local.UserPreferences
import com.example.data.repository.ChatRepository
import com.example.data.remote.*
import com.example.utils.GeminiJsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val chatDao = AppDatabase.getDatabase(application).chatDao()
    private val repository = ChatRepository(chatDao)
    val userPrefs = UserPreferences(application)

    // Visualization and Lesson states
    private val _activeVisual = MutableStateFlow<EducationalVisual?>(null)
    val activeVisual: StateFlow<EducationalVisual?> = _activeVisual.asStateFlow()

    private val _isGeneratingVisual = MutableStateFlow(false)
    val isGeneratingVisual: StateFlow<Boolean> = _isGeneratingVisual.asStateFlow()

    private val _activeLesson = MutableStateFlow<TeachMeLesson?>(null)
    val activeLesson: StateFlow<TeachMeLesson?> = _activeLesson.asStateFlow()

    private val _isGeneratingLesson = MutableStateFlow(false)
    val isGeneratingLesson: StateFlow<Boolean> = _isGeneratingLesson.asStateFlow()

    val allSessions: StateFlow<List<ChatSession>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestSession: StateFlow<ChatSession?> = repository.latestSession
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _currentSessionId = MutableStateFlow<String?>(null)
    val currentSessionId: StateFlow<String?> = _currentSessionId.asStateFlow()

    private val _isReplying = MutableStateFlow(false)
    val isReplying: StateFlow<Boolean> = _isReplying.asStateFlow()

    private val _inputMessage = MutableStateFlow("")
    val inputMessage: StateFlow<String> = _inputMessage.asStateFlow()

    // Dynamically fetch messages for the active session
    val currentMessages: StateFlow<List<ChatMessage>> = _currentSessionId
        .flatMapLatest { sessionId ->
            if (sessionId != null) {
                repository.getMessagesForSession(sessionId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Automatically set or create a default session on start if there's none
        viewModelScope.launch {
            latestSession.collectLatest { session ->
                if (_currentSessionId.value == null && session != null) {
                    _currentSessionId.value = session.id
                }
            }
        }
    }

    fun onInputChange(text: String) {
        _inputMessage.value = text
    }

    fun selectSession(sessionId: String) {
        _currentSessionId.value = sessionId
    }

    fun startNewChat(title: String = "Chat ${allSessions.value.size + 1}") {
        viewModelScope.launch {
            val newId = UUID.randomUUID().toString()
            repository.createSession(newId, title)
            _currentSessionId.value = newId
        }
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            if (_currentSessionId.value == sessionId) {
                _currentSessionId.value = allSessions.value.firstOrNull { it.id != sessionId }?.id
            }
        }
    }

    fun clearCurrentSession() {
        val currentId = _currentSessionId.value ?: return
        viewModelScope.launch {
            repository.clearSessionMessages(currentId)
        }
    }

    fun sendMessage() {
        val prompt = _inputMessage.value.trim()
        if (prompt.isEmpty() || _isReplying.value) return

        var currentId = _currentSessionId.value
        viewModelScope.launch {
            _isReplying.value = true
            _inputMessage.value = ""

            // Create active session if none exists
            if (currentId == null) {
                val newId = UUID.randomUUID().toString()
                val sessionTitle = if (prompt.length > 20) prompt.take(20) + "..." else prompt
                repository.createSession(newId, sessionTitle)
                _currentSessionId.value = newId
                currentId = newId
            }

            val gender = userPrefs.userGender.value
            val genderTitle = userPrefs.getGenderTitle()
            val systemInstruction = buildSystemInstruction(gender)

            repository.sendMessage(currentId, prompt, systemInstruction, genderTitle)
            _isReplying.value = false
        }
    }

    fun sendSuggestionPrompt(prompt: String) {
        if (_isReplying.value) return
        _inputMessage.value = prompt
        sendMessage()
    }

    fun generateVisualization(topic: String, explanationText: String) {
        viewModelScope.launch {
            _isGeneratingVisual.value = true
            _activeVisual.value = null
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                    val fallback = GeminiJsonParser.createFallbackVisual(topic, explanationText)
                    _activeVisual.value = fallback
                    _isGeneratingVisual.value = false
                    return@launch
                }

                val systemInstructionText = """
                    You are TT AI, the official premium visualization system of Technical Thinkers.
                    Based on the explanation text provided, generate a beautiful educational diagram mapping.
                    You MUST respond with a single, strictly valid JSON block matching this EducationalVisual Kotlin schema:
                    {
                      "type": "FLOWCHART" | "BINARY_TREE" | "TIMELINE" | "CONCEPT_MAP" | "LABELED_ANATOMY" | "NETWORK_TOPOLOGY" | "SOLAR_SYSTEM" | "CHEMISTRY_MOLECULE" | "MATH_GRAPH" | "GENERIC_DIAGRAM",
                      "title": "Title of the diagram",
                      "nodes": [
                        {"id": "uniqueString", "label": "Short Label", "type": "default"|"star"|"planet"|"server"|"router"|"atom"|"step"|"concept", "x": 10.0, "y": 10.0, "description": "Brief educational details about this item."}
                      ],
                      "edges": [
                        {"from": "nodeId1", "to": "nodeId2", "label": "optional description", "isDirected": true, "style": "solid"|"dashed"}
                      ],
                      "explanationInTenglish": "Detailed, friendly, and simple explanation of the diagram in Tenglish (Telugu in English letters), addressing the user warmly as Mama/Mawaa/Madammm as appropriate. Explain the layout and components.",
                      "annotations": ["Pinch to zoom", "Tap nodes for details"]
                    }
                    Ensure nodes have spacious layout percentage positions (x and y between 10.0 and 90.0) so elements do not overlap. Node coordinates must be Floats.
                    Only output the raw JSON object. Do NOT wrap it in any text or conversational prefixes, just pure parsable JSON block.
                """.trimIndent()

                val prompt = "Based on this explanation, generate a visualization diagram JSON: $explanationText"

                val request = GenerateContentRequest(
                    contents = listOf(Content(parts = listOf(Part(text = prompt)))),
                    systemInstruction = Content(parts = listOf(Part(text = systemInstructionText)))
                )

                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.service.generateContent(
                        model = "gemini-3.5-flash",
                        apiKey = apiKey,
                        request = request
                    )
                }

                val jsonResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                val parsed = jsonResponse?.let { GeminiJsonParser.parseVisual(it) }

                if (parsed != null) {
                    _activeVisual.value = parsed
                } else {
                    _activeVisual.value = GeminiJsonParser.createFallbackVisual(topic, explanationText)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _activeVisual.value = GeminiJsonParser.createFallbackVisual(topic, explanationText)
            } finally {
                _isGeneratingVisual.value = false
            }
        }
    }

    fun generateTeachMeLesson(topic: String) {
        viewModelScope.launch {
            _isGeneratingLesson.value = true
            _activeLesson.value = null
            val currentLevel = userPrefs.userLevel.value
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                    createFallbackLesson(topic, currentLevel)
                    _isGeneratingLesson.value = false
                    return@launch
                }

                val systemInstructionText = """
                    You are TT AI, the master educational instructor of Technical Thinkers.
                    You build step-by-step interactive lessons that adapt to the user's level (Beginner or Advanced).
                    You MUST respond with a single, strictly valid JSON block matching this TeachMeLesson Kotlin schema:
                    {
                      "topic": "$topic",
                      "level": "$currentLevel",
                      "explanation": "Provide a clean, comprehensive, step-by-step lesson explanation in Tenglish (Telugu written in English letters). Adapt depth to level: Beginner gets simple words; Advanced gets technical details.",
                      "realLifeExample": "Relate this topic to a fun, vivid real-world scenario or analogy in Tenglish.",
                      "visualization": {
                        "type": "FLOWCHART" | "BINARY_TREE" | "TIMELINE" | "CONCEPT_MAP" | "LABELED_ANATOMY" | "NETWORK_TOPOLOGY" | "SOLAR_SYSTEM" | "CHEMISTRY_MOLECULE" | "MATH_GRAPH" | "GENERIC_DIAGRAM",
                        "title": "Diagram Title",
                        "nodes": [{"id": "n1", "label": "Label", "type": "default", "x": 10.0, "y": 10.0, "description": "Description"}],
                        "edges": [{"from": "n1", "to": "n2", "label": "Link", "isDirected": true, "style": "solid"}],
                        "explanationInTenglish": "A simple Tenglish description explaining the components and flow of the visualization.",
                        "annotations": ["Annotation text"]
                      },
                      "quiz": {
                        "question": "A multiple-choice question testing their understanding.",
                        "options": ["Option 1", "Option 2", "Option 3", "Option 4"],
                        "correctIndex": 0,
                        "explanation": "Clear explanation of the correct answer in easy Tenglish."
                      },
                      "practice": {
                        "question": "A challenge problem statement requiring thinking.",
                        "hint": "Useful hint",
                        "sampleSolution": "Step-by-step ideal solution."
                      },
                      "summary": "Key summary takeaways from this lesson in Tenglish.",
                      "nextTopicRecommendation": "Recommend the next topic they should learn."
                    }
                    Only output the raw JSON object. Do NOT write any chat dialog or markdown formatting outside the JSON code boundaries.
                """.trimIndent()

                val prompt = "Create a custom lesson on the topic of '$topic' for a $currentLevel learner."

                val request = GenerateContentRequest(
                    contents = listOf(Content(parts = listOf(Part(text = prompt)))),
                    systemInstruction = Content(parts = listOf(Part(text = systemInstructionText)))
                )

                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.service.generateContent(
                        model = "gemini-3.5-flash",
                        apiKey = apiKey,
                        request = request
                    )
                }

                val jsonResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                val parsed = jsonResponse?.let { GeminiJsonParser.parseLesson(it) }

                if (parsed != null) {
                    _activeLesson.value = parsed
                } else {
                    createFallbackLesson(topic, currentLevel)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                createFallbackLesson(topic, currentLevel)
            } finally {
                _isGeneratingLesson.value = false
            }
        }
    }

    private fun createFallbackLesson(topic: String, level: String) {
        val visual = GeminiJsonParser.createFallbackVisual(topic, "Fallback visualization for lesson")
        _activeLesson.value = TeachMeLesson(
            topic = topic,
            level = level,
            explanation = "Mama 😄, explanation prepare cheyadam lo chinna error vachindi, but don't worry!\n\n'$topic' ante chala simple. Edi direct interactive interface. Meru general sections check cheyyochu and continuous ga graphics nodes chudadaniki local generator setup ready chesa. $level level specifications based ga details read cheyyandi!",
            realLifeExample = "Technical Thinkers learning system: concepts and interactive details are clearly linked directly in diagrams.",
            visualization = visual,
            quiz = InteractiveQuiz(
                question = "Is '$topic' easy to understand with our interactive diagrams?",
                options = listOf("Yes, super easy", "No, need more details", "Maybe", "Don't know"),
                correctIndex = 0,
                explanation = "Yes! Our custom local coordinate framework resolves rendering correctly!"
            ),
            practice = PracticeQuestion(
                question = "How would you implement the core concept of $topic in your own project?",
                hint = "Think about separating UI drawing components from content parsing nodes.",
                sampleSolution = "Create clean structured nodes, scale them dynamically using Pinch gestures, and render using Canvas lines!"
            ),
            summary = "$topic features are successfully rendered inside our custom Compose canvas.",
            nextTopicRecommendation = "Advanced UI Gestures & Vector Drawings"
        )
    }

    fun clearActiveVisual() {
        _activeVisual.value = null
    }

    fun clearActiveLesson() {
        _activeLesson.value = null
    }

    fun exportChatHistory(): String {
        val messages = currentMessages.value
        val genderTitle = userPrefs.getGenderTitle()
        if (messages.isEmpty()) return "No chat history to export, $genderTitle! 😅"
        
        return buildString {
            appendLine("=== Technical Thinkers AI Chat Export ===")
            appendLine("Session ID: ${_currentSessionId.value}")
            appendLine("Exported on: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}")
            appendLine("=========================================\n")
            messages.forEach { msg ->
                val sender = if (msg.role == "user") "You" else "TT AI"
                val time = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(msg.timestamp))
                appendLine("[$time] $sender: ${msg.content}")
                appendLine()
            }
        }
    }

    private fun buildSystemInstruction(gender: String): String {
        val genderCall = when (gender) {
            "Male" -> "Maawaaa (for males)"
            "Female" -> "Madammm (for females)"
            else -> "Friend (for unknown gender)"
        }
        return """
            You are TT AI, the official premium AI assistant of Technical Thinkers.
            Tagline: Learn. Build. Grow.
            
            Personality & Rules:
            1. Speak naturally in Tenglish (a lively mix of Telugu and English, using English letters).
            2. DO NOT use Telugu script (Telugu letters like తెలుగు) unless the user specifically asks you to. Always write Telugu words in English letters.
            3. DO NOT write answers solely in English, unless the user asks in English or specifically requests only English. Maintain a healthy, friendly, energetic blend of English and Telugu (Tenglish) naturally.
            4. Addressing the user:
               - You MUST address the user based on their gender configuration:
                 - If Male: call them 'Maawaaa' (e.g., 'Cheppu Maawaaa', 'Sarre Maawaaa', 'Ela unnav Maawaaa?').
                 - If Female: call them 'Madammm' (e.g., 'Cheppu Madammm', 'Sarre Madammm', 'Ela unnar Madammm?').
                 - If Unknown/Other: call them 'Friend' (e.g., 'Cheppu Friend', 'Malli try cheyyi Friend').
               - Strictly follow this addressing rule. Never assume or change it unless instructed.
            5. Tone and Mood Adaptation:
               - If the user is learning: Become an encouraging, smart teacher.
               - If the user needs career guidance: Become an experienced mentor.
               - If the user wants coding: Become an expert programmer who writes clean code. Explain key points and give clear code blocks.
               - If the user is sad: Be supportive, warm, and highly empathetic.
               - If the user is joking/playful: Reply playfully, use fun emojis, and be witty.
               - Never sound robotic. Always be conversational, warm, and friendly.
            6. Scope:
               - You are NOT limited to technology. You can answer questions on any topic including education, science, medicine (general info only), business, finance, coding, history, geography, psychology, mathematics, careers, fitness, travel, movies, sports, languages, productivity, relationships, etc.
               - Always provide accurate, helpful, and honest answers. If you are uncertain about something, clearly say you are not sure instead of inventing information.
            7. Length: Use short, snappy replies for casual chats, but provide rich, well-formatted, detailed explanations when asked. Use emojis naturally.
        """.trimIndent()
    }
}
