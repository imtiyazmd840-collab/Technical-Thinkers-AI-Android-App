package com.example.utils

import com.example.data.remote.EducationalVisual
import com.example.data.remote.TeachMeLesson
import com.example.data.remote.VisualEdge
import com.example.data.remote.VisualNode
import com.example.data.remote.VisualType
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.util.regex.Pattern

object GeminiJsonParser {

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    fun parseVisual(rawInput: String): EducationalVisual? {
        val jsonString = extractJsonString(rawInput) ?: return null
        return try {
            val adapter = moshi.adapter(EducationalVisual::class.java)
            adapter.fromJson(jsonString)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun parseLesson(rawInput: String): TeachMeLesson? {
        val jsonString = extractJsonString(rawInput) ?: return null
        return try {
            val adapter = moshi.adapter(TeachMeLesson::class.java)
            adapter.fromJson(jsonString)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun extractJsonString(rawInput: String): String? {
        // Regex to match markdown JSON code block
        val pattern = Pattern.compile("```(?:json)?\\s*([\\s\\S]*?)\\s*```", Pattern.CASE_INSENSITIVE)
        val matcher = pattern.matcher(rawInput)
        if (matcher.find()) {
            return matcher.group(1).trim()
        }
        
        // If no code block, look for first '{' and last '}'
        val start = rawInput.indexOf('{')
        val end = rawInput.lastIndexOf('}')
        if (start != -1 && end != -1 && end > start) {
            return rawInput.substring(start, end + 1).trim()
        }
        
        return null
    }

    fun createFallbackVisual(topic: String, description: String = ""): EducationalVisual {
        // Guess the visual type based on keywords
        val lowerTopic = topic.lowercase()
        val type = when {
            lowerTopic.contains("heart") || lowerTopic.contains("anatomy") || lowerTopic.contains("body") || lowerTopic.contains("brain") -> VisualType.LABELED_ANATOMY
            lowerTopic.contains("solar") || lowerTopic.contains("orbit") || lowerTopic.contains("planet") || lowerTopic.contains("system") -> VisualType.SOLAR_SYSTEM
            lowerTopic.contains("binary") || lowerTopic.contains("tree") || lowerTopic.contains("bst") -> VisualType.BINARY_TREE
            lowerTopic.contains("network") || lowerTopic.contains("topology") || lowerTopic.contains("server") -> VisualType.NETWORK_TOPOLOGY
            lowerTopic.contains("molecule") || lowerTopic.contains("chemistry") || lowerTopic.contains("water") || lowerTopic.contains("atom") -> VisualType.CHEMISTRY_MOLECULE
            lowerTopic.contains("timeline") || lowerTopic.contains("history") || lowerTopic.contains("year") -> VisualType.TIMELINE
            lowerTopic.contains("graph") || lowerTopic.contains("math") || lowerTopic.contains("equation") || lowerTopic.contains("plot") -> VisualType.MATH_GRAPH
            lowerTopic.contains("flow") || lowerTopic.contains("step") || lowerTopic.contains("program") -> VisualType.FLOWCHART
            else -> VisualType.CONCEPT_MAP
        }

        // Generate relevant fallback nodes
        val nodes = when (type) {
            VisualType.BINARY_TREE -> listOf(
                VisualNode("root", "Root Node", "concept", 50f, 15f, "Root element of the binary tree"),
                VisualNode("left", "Left Child", "concept", 30f, 45f, "Left subtree branch"),
                VisualNode("right", "Right Child", "concept", 70f, 45f, "Right subtree branch"),
                VisualNode("left_left", "Left Leaf", "concept", 15f, 75f, "Leaf element"),
                VisualNode("left_right", "Right Leaf", "concept", 45f, 75f, "Leaf element")
            )
            VisualType.FLOWCHART -> listOf(
                VisualNode("start", "START", "step", 50f, 15f, "Start point of execution"),
                VisualNode("process", "Process Data", "step", 50f, 45f, "Perform computation or operations"),
                VisualNode("end", "END / SUCCESS", "step", 50f, 75f, "Execution finishes successfully")
            )
            VisualType.TIMELINE -> listOf(
                VisualNode("t1", "Event A (Past)", "concept", 20f, 50f, "The first foundational occurrence"),
                VisualNode("t2", "Event B (Present)", "concept", 50f, 50f, "Current active developments"),
                VisualNode("t3", "Event C (Future)", "concept", 80f, 50f, "Predicted future outcomes")
            )
            VisualType.NETWORK_TOPOLOGY -> listOf(
                VisualNode("client", "User Device", "concept", 20f, 50f, "Client browser or application"),
                VisualNode("router", "API Router", "concept", 50f, 50f, "Directs traffic to core microservices"),
                VisualNode("server", "Main Server", "concept", 80f, 25f, "Backend computing environment"),
                VisualNode("db", "Spanner DB", "concept", 80f, 75f, "Relational local/cloud storage database")
            )
            VisualType.SOLAR_SYSTEM -> listOf(
                VisualNode("sun", "The Sun", "concept", 50f, 50f, "The massive star at the solar center"),
                VisualNode("p1", "Inner Planet", "concept", 32f, 35f, "Orbiting close with high velocity"),
                VisualNode("p2", "Outer Planet", "concept", 72f, 65f, "A gas giant located further out")
            )
            VisualType.LABELED_ANATOMY -> listOf(
                VisualNode("core", "Central Core", "concept", 50f, 45f, "Main organ functional chamber"),
                VisualNode("left_lobe", "Left Lobe", "concept", 25f, 35f, "Left auxiliary compartment"),
                VisualNode("right_lobe", "Right Lobe", "concept", 75f, 35f, "Right auxiliary compartment"),
                VisualNode("artery", "Main Valve", "concept", 50f, 75f, "Inflow/outflow channel pathway")
            )
            else -> listOf(
                VisualNode("n1", "Main Subject", "concept", 50f, 30f, "Central point of this topic"),
                VisualNode("n2", "Related Node 1", "concept", 30f, 70f, "First secondary subtopic connection"),
                VisualNode("n3", "Related Node 2", "concept", 70f, 70f, "Second secondary subtopic connection")
            )
        }

        val edges = when (type) {
            VisualType.BINARY_TREE -> listOf(
                VisualEdge("root", "left", "L", true),
                VisualEdge("root", "right", "R", true),
                VisualEdge("left", "left_left", "L", true),
                VisualEdge("left", "left_right", "R", true)
            )
            VisualType.FLOWCHART -> listOf(
                VisualEdge("start", "process", "Proceed", true),
                VisualEdge("process", "end", "Complete", true)
            )
            VisualType.TIMELINE -> listOf(
                VisualEdge("t1", "t2", "Then", true),
                VisualEdge("t2", "t3", "Later", true)
            )
            VisualType.NETWORK_TOPOLOGY -> listOf(
                VisualEdge("client", "router", "HTTPS Request", true),
                VisualEdge("router", "server", "Route", true),
                VisualEdge("server", "db", "Query", true)
            )
            VisualType.SOLAR_SYSTEM -> listOf(
                VisualEdge("p1", "sun", "Gravity Pull", false, "dashed"),
                VisualEdge("p2", "sun", "Gravity Pull", false, "dashed")
            )
            VisualType.LABELED_ANATOMY -> listOf(
                VisualEdge("left_lobe", "core", "Oxygen Flow", true),
                VisualEdge("right_lobe", "core", "Oxygen Flow", true),
                VisualEdge("core", "artery", "Exit Valve", true)
            )
            else -> listOf(
                VisualEdge("n1", "n2", "Linked", false),
                VisualEdge("n1", "n3", "Linked", false)
            )
        }

        return EducationalVisual(
            type = type,
            title = "Diagram: $topic",
            nodes = nodes,
            edges = edges,
            explanationInTenglish = "Mama 😄, image loading failed, but don't worry! Nenu local ga graphical visualization design chesa.\n\nEey visual diagram '$topic' ni simplify chestundi. Clear ga coordinates & relations map ayi unnay, check cheyyi!",
            annotations = listOf("Drag nodes to interact", "Pinch to Zoom", "Tap for information details")
        )
    }
}
