package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PeopleOutline
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.CommunityScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.components.TechnicalThinkersLogo
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.HomeViewModel
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.*
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.NavigationDrawerItemDefaults

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val chatViewModel: ChatViewModel = viewModel()
            val homeViewModel: HomeViewModel = viewModel()

            // Observe dark theme preference reactively
            val isDarkMode by chatViewModel.userPrefs.isDarkMode.collectAsState()

            MyApplicationTheme(darkTheme = isDarkMode) {
                AppShell(
                    chatViewModel = chatViewModel,
                    homeViewModel = homeViewModel
                )
            }
        }
    }
}

@Composable
fun AppShell(
    chatViewModel: ChatViewModel,
    homeViewModel: HomeViewModel
) {
    var showSplash by remember { mutableStateOf(true) }

    if (showSplash) {
        SplashScreen(onSplashFinished = { showSplash = false })
    } else {
        var currentTab by remember { mutableStateOf("home") }
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val coroutineScope = rememberCoroutineScope()

        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    drawerShape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp),
                    modifier = Modifier.width(300.dp)
                ) {
                    // Header
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        BrandPrimary.copy(alpha = 0.15f),
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.1f)
                                    )
                                )
                            )
                            .padding(vertical = 32.dp, horizontal = 24.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            TechnicalThinkersLogo(
                                modifier = Modifier.size(64.dp),
                                fallbackSize = 36.dp
                            )
                            Column {
                                Text(
                                    text = "Technical Thinkers",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Learn. Build. Grow. 🚀",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = BrandPrimary
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                    Spacer(modifier = Modifier.height(16.dp))

                    // Navigation Items
                    val items = listOf(
                        NavigationItem("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
                        NavigationItem("chat", "AI Chat", Icons.Filled.ChatBubble, Icons.Outlined.ChatBubbleOutline),
                        NavigationItem("community", "Community", Icons.Filled.People, Icons.Outlined.PeopleOutline),
                        NavigationItem("profile", "Profile", Icons.Filled.Person, Icons.Outlined.PersonOutline)
                    )

                    items.forEach { item ->
                        val isSelected = currentTab == item.id
                        NavigationDrawerItem(
                            label = { Text(item.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) },
                            selected = isSelected,
                            onClick = {
                                currentTab = item.id
                                coroutineScope.launch { drawerState.close() }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.label,
                                    tint = if (isSelected) BrandPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = BrandPrimary.copy(alpha = 0.12f),
                                unselectedContainerColor = Color.Transparent
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    Text(
                        text = "Version 1.0 (Production)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        ) {
            Scaffold(
                bottomBar = {
                    // Only show the navigation bar when not on the Settings page to maintain visual focus
                    if (currentTab != "settings") {
                        NavigationBar(
                            tonalElevation = 8.dp,
                            modifier = Modifier.testTag("bottom_navigation")
                        ) {
                            val tabs = listOf(
                                NavigationItem("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
                                NavigationItem("chat", "AI Chat", Icons.Filled.ChatBubble, Icons.Outlined.ChatBubbleOutline),
                                NavigationItem("community", "Community", Icons.Filled.People, Icons.Outlined.PeopleOutline),
                                NavigationItem("profile", "Profile", Icons.Filled.Person, Icons.Outlined.PersonOutline)
                            )

                            tabs.forEach { item ->
                                val isSelected = currentTab == item.id
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { currentTab = item.id },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label,
                                            tint = if (isSelected) BrandPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = item.label,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 11.sp,
                                            letterSpacing = 0.2.sp
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        indicatorColor = BrandPrimary.copy(alpha = 0.12f)
                                    )
                                )
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxSize()
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    // Render active screen cleanly
                    when (currentTab) {
                        "home" -> HomeScreen(
                            viewModel = homeViewModel,
                            onNavigateToChat = { sessionId ->
                                if (sessionId != null) {
                                    chatViewModel.selectSession(sessionId)
                                } else {
                                    chatViewModel.startNewChat()
                                }
                                currentTab = "chat"
                            },
                            onNavigateToChatWithPrompt = { prompt ->
                                chatViewModel.sendSuggestionPrompt(prompt)
                                currentTab = "chat"
                            },
                            onOpenDrawer = {
                                coroutineScope.launch { drawerState.open() }
                            }
                        )
                        "chat" -> ChatScreen(
                            viewModel = chatViewModel,
                            onOpenDrawer = {
                                coroutineScope.launch { drawerState.open() }
                            }
                        )
                        "community" -> CommunityScreen(
                            onOpenDrawer = {
                                coroutineScope.launch { drawerState.open() }
                            }
                        )
                        "profile" -> ProfileScreen(
                            viewModel = chatViewModel,
                            onNavigateToSettings = { currentTab = "settings" },
                            onOpenDrawer = {
                                coroutineScope.launch { drawerState.open() }
                            }
                        )
                        "settings" -> SettingsScreen(
                            viewModel = chatViewModel,
                            onBack = { currentTab = "profile" }
                        )
                    }
                }
            }
        }
    }
}

data class NavigationItem(
    val id: String,
    val label: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector
)
