package com.example.data.remote

import com.squareup.moshi.JsonClass

enum class VisualType {
    FLOWCHART,
    BINARY_TREE,
    TIMELINE,
    CONCEPT_MAP,
    LABELED_ANATOMY,
    NETWORK_TOPOLOGY,
    SOLAR_SYSTEM,
    CHEMISTRY_MOLECULE,
    MATH_GRAPH,
    GENERIC_DIAGRAM
}

@JsonClass(generateAdapter = true)
data class VisualNode(
    val id: String,
    val label: String,
    val type: String = "default", // e.g., "star", "planet", "server", "router", "atom", "step", "concept", "part"
    val x: Float, // percentage coordinates 0..100
    val y: Float, // percentage coordinates 0..100
    val description: String? = null
)

@JsonClass(generateAdapter = true)
data class VisualEdge(
    val from: String,
    val to: String,
    val label: String? = null,
    val isDirected: Boolean = true,
    val style: String = "solid" // "solid" or "dashed"
)

@JsonClass(generateAdapter = true)
data class EducationalVisual(
    val type: VisualType,
    val title: String,
    val nodes: List<VisualNode>,
    val edges: List<VisualEdge>,
    val explanationInTenglish: String,
    val annotations: List<String> = emptyList()
)
