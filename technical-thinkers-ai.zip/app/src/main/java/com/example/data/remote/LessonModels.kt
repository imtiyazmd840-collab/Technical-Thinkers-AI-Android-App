package com.example.data.remote

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class InteractiveQuiz(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

@JsonClass(generateAdapter = true)
data class PracticeQuestion(
    val question: String,
    val hint: String,
    val sampleSolution: String
)

@JsonClass(generateAdapter = true)
data class TeachMeLesson(
    val topic: String,
    val level: String, // "Beginner" or "Advanced"
    val explanation: String, // Step by step lesson content in lively Tenglish/English
    val realLifeExample: String, // Vivid real-life scenario
    val visualization: EducationalVisual?, // The accompanying visual model for this lesson
    val quiz: InteractiveQuiz,
    val practice: PracticeQuestion,
    val summary: String,
    val nextTopicRecommendation: String
)
