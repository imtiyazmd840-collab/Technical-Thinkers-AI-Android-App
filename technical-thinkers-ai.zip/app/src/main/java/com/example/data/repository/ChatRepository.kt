package com.example.data.repository

import android.util.Log
import com.example.BuildConfig
import com.example.data.local.ChatDao
import com.example.data.local.ChatMessage
import com.example.data.local.ChatSession
import com.example.data.remote.Content
import com.example.data.remote.GenerateContentRequest
import com.example.data.remote.Part
import com.example.data.remote.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ChatRepository(private val chatDao: ChatDao) {

    val allSessions: Flow<List<ChatSession>> = chatDao.getAllSessions()
    val latestSession: Flow<ChatSession?> = chatDao.getLatestSession()

    fun getMessagesForSession(sessionId: String): Flow<List<ChatMessage>> {
        return chatDao.getMessagesForSession(sessionId)
    }

    suspend fun createSession(sessionId: String, title: String) = withContext(Dispatchers.IO) {
        chatDao.insertSession(ChatSession(id = sessionId, title = title))
    }

    suspend fun deleteSession(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.deleteSession(sessionId)
    }

    suspend fun clearSessionMessages(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.clearMessagesForSession(sessionId)
    }

    suspend fun deleteAllData() = withContext(Dispatchers.IO) {
        chatDao.deleteAllMessages()
        chatDao.deleteAllSessions()
    }

    suspend fun sendMessage(
        sessionId: String,
        userContent: String,
        systemInstructionText: String,
        genderTitle: String
    ): String = withContext(Dispatchers.IO) {
        try {
            // 1. Save user message to Room
            val userMessage = ChatMessage(
                sessionId = sessionId,
                role = "user",
                content = userContent,
                timestamp = System.currentTimeMillis()
            )
            chatDao.insertMessage(userMessage)

            // 2. Fetch history for this session from Room to pass context to Gemini
            val history = chatDao.getMessagesForSessionSync(sessionId)
            val apiContents = history.map { msg ->
                Content(
                    role = if (msg.role == "user") "user" else "model",
                    parts = listOf(Part(text = msg.content))
                )
            }

            // 3. Prepare Gemini API details
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                val errorMsg = "Ayyoo, API Key ledhu $genderTitle! 😅 AI Studio Settings lo ledha Secrets panel lo 'GEMINI_API_KEY' add cheyyi. Appudu nenu ready ga answers cheptha!"
                saveAiResponse(sessionId, errorMsg)
                return@withContext errorMsg
            }

            val request = GenerateContentRequest(
                contents = apiContents,
                systemInstruction = Content(
                    parts = listOf(Part(text = systemInstructionText))
                )
            )

            // Call standard 'gemini-3.5-flash' model for smart, responsive conversational text
            val response = RetrofitClient.service.generateContent(
                model = "gemini-3.5-flash",
                apiKey = apiKey,
                request = request
            )

            val aiResponseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "Ayyoo, response khali ga vachindi $genderTitle! 😅 Malli adugu, em parledhu."

            // 4. Save AI response to Room
            saveAiResponse(sessionId, aiResponseText)
            return@withContext aiResponseText

        } catch (e: Exception) {
            Log.e("ChatRepository", "Error sending message", e)
            val errorMsg = "Sarre $genderTitle, chinna problem vachindi! Network check chesko ledha koddiga aagi try cheyyi. 😅 (Error: ${e.localizedMessage})"
            saveAiResponse(sessionId, errorMsg)
            return@withContext errorMsg
        }
    }

    private suspend fun saveAiResponse(sessionId: String, text: String) {
        chatDao.insertMessage(
            ChatMessage(
                sessionId = sessionId,
                role = "model",
                content = text,
                timestamp = System.currentTimeMillis()
            )
        )
    }
}
