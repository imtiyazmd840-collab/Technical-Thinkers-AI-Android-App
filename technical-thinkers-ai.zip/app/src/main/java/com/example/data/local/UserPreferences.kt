package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserPreferences(context: Context) {
    private val sharedPrefs: SharedPreferences = context.getSharedPreferences("tt_ai_prefs", Context.MODE_PRIVATE)

    private val _isDarkMode = MutableStateFlow(sharedPrefs.getBoolean("dark_mode", true)) // default dark mode as per ChatGPT/Gemini style
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _isNotificationsEnabled = MutableStateFlow(sharedPrefs.getBoolean("notifications_enabled", true))
    val isNotificationsEnabled: StateFlow<Boolean> = _isNotificationsEnabled.asStateFlow()

    private val _userGender = MutableStateFlow(sharedPrefs.getString("user_gender", "Unknown") ?: "Unknown")
    val userGender: StateFlow<String> = _userGender.asStateFlow()

    private val _userLevel = MutableStateFlow(sharedPrefs.getString("user_level", "Beginner") ?: "Beginner")
    val userLevel: StateFlow<String> = _userLevel.asStateFlow()

    fun setDarkMode(enabled: Boolean) {
        sharedPrefs.edit().putBoolean("dark_mode", enabled).apply()
        _isDarkMode.value = enabled
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        sharedPrefs.edit().putBoolean("notifications_enabled", enabled).apply()
        _isNotificationsEnabled.value = enabled
    }

    fun setUserGender(gender: String) {
        sharedPrefs.edit().putString("user_gender", gender).apply()
        _userGender.value = gender
    }

    fun setUserLevel(level: String) {
        sharedPrefs.edit().putString("user_level", level).apply()
        _userLevel.value = level
    }

    fun getGenderTitle(): String {
        return when (_userGender.value) {
            "Male" -> "Maawaaa"
            "Female" -> "Madammm"
            else -> "Friend"
        }
    }
}
